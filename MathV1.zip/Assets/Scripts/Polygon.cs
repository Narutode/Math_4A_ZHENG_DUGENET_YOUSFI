using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Polygon
{
    public List<Vector2> Sommets = new List<Vector2>();
}
